<div class="row">
	<div class="col-md-12">

    <div class="alert alert-primary" role="alert">
    Design By: Nasrul &copy; 2021
    </div>

	</div>
</div>