<h3>Form Login</h3>
<form method="POST" action="controllers/memberController.php">
  <div class="form-group">
    <label>Username</label>
    <input type="text" name="username" class="form-control">
   </div>
  <div class="form-group">
    <label>Password</label>
    <input type="password" class="form-control" name="password">
  </div>
  <button type="submit" class="btn btn-primary">Login</button>
</form>